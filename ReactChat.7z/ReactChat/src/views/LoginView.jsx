import Login from "../components/Login";


function LoginView () {
    return (
        <>
            <h1>Login</h1>
            <Login/>
            
        </>
    )
}

export default LoginView